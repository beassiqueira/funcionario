/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionario;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author nina bea rai
 */
public class CLASS_FUNCIONARIO {

    private String nome;
    private Date Admissao;
    private float horas;
    private float trabalhadas;
    public String getNome() {
        return nome;
        
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataAdmissao() {
        return Admissao;
    }

    public void setDataAdmissao(Date dataAdmissao) {
        this.Admissao = dataAdmissao;
    }

    public float getValor_horas() {
        return horas;
    }

    public void setValor_horas(float valor_horas) {
        this.horas = valor_horas;
    }

    public float getHoras_trabalhadas() {
        return trabalhadas;
    }

    public void setHoras_trabalhadas(float horas_trabalhadas) {
        this.trabalhadas = horas_trabalhadas;
    }
    int i;

    public int calcularTempoempresa() {
        Calendar dataADM = Calendar.getInstance();
        dataADM.setTime(Admissao);
        Calendar hoje = Calendar.getInstance();
        hoje.getTime();
        i = hoje.get(Calendar.YEAR) - dataADM.get(Calendar.YEAR);
        dataADM.add(Calendar.YEAR, i);
        if (hoje.before(dataADM)) {
            i--;
        }
        return i;
    }
    public float calcularSalario() {
        float sal = ((horas * trabalhadas));
        float sal_reajustado5 = sal*0.05f, sal_reajustado10 = sal*0.10f;
        
        int y = calcularTempoempresa();
        if (y >= 5 && y < 10) {
             sal += sal_reajustado5;
        } else if (y >= 10) {
            sal += sal_reajustado10;
        }
        return sal;

    }
}
